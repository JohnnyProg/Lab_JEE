package com.gryta.pai_lab7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaiLab7Application {

	public static void main(String[] args) {
		SpringApplication.run(PaiLab7Application.class, args);
	}

}
